<?php

// Text
$_['text_title'] = 'Collector Checkout';
