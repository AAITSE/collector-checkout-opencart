<?php

// Text
$_['text_title'] = 'Collector Checkout';
$_['text_items'] = '%s item(s) - %s';

