<?php

/**
 * Compatibility for OpenCart 2.1
 */

require_once DIR_APPLICATION . '/model/extension/payment/' . basename(__FILE__);

class ModelPaymentCollector extends ModelExtensionPaymentCollector {
    //
}
