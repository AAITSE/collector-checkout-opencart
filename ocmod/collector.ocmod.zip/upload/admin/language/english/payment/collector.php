<?php

/**
 * Compatibility for OpenCart 2.1
 */

require_once DIR_APPLICATION . '/language/en-gb/extension/payment/' . basename(__FILE__);
