<?php

/**
 * Compatibility for OpenCart 2.1
 */

require_once DIR_APPLICATION . '/controller/extension/payment/' . basename(__FILE__);

class ControllerPaymentCollector extends ControllerExtensionPaymentCollector
{
    //
}
